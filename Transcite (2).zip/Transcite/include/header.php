<?php
include("biblioAccessBDD.php");
$bdd=seConnecter();
?>
<header class="jumbotron text-center" style="margin-bottom:0">
  <h1>Transcite</h1>
</header>