<?php

function seConnecter()
{// port 3306 si mysql et 3307 si mariadb
   $serveur = 'mysql:host=localhost;port=3306';
   $bdd = 'dbname=Transcite';
   $user = 'root';
   $mdp = '';
   try {
      $pdo = new PDO($serveur . ';' . $bdd . ';charset=UTF8', $user, $mdp);
   } catch (PDOException $e) {
      echo ('Erreur : ' . $e->getMessage());
   }
   return $pdo;
};

function getLigne($bdd)
{
    $req = "SELECT * FROM Ligne";
    $res = $bdd->query($req);
    $lesLignes = $res->fetchAll();
    return $lesLignes;
}

function getGuichet($bdd)
{
    $req = "SELECT l.idLigne AS ligne, COUNT(s.idStation) AS nombre_stations_sans_guichet
            FROM Ligne l
            JOIN Se_Situer se ON se.numLigne = l.idLigne
            JOIN Station s ON se.numStation = s.idStation
            WHERE s.pointDeVente = FALSE
            GROUP BY l.idLigne";
    $res = $bdd->query($req);
    $NombreStation = $res->fetchAll();
    return $NombreStation;
}

function GetSatisfaction($bdd)
{
    $req = "SELECT s.degre AS satisfaction_degre, COUNT(cm.idCommentaire) AS nombre_commentaires
            FROM Commentaire cm
            JOIN Critere c ON cm.idCritere = c.idCritere
            JOIN Satisfaction s ON cm.idSatisfaction = s.idSatisfaction
            WHERE c.libelle = 'Fréquence de bus'
            GROUP BY s.degre";
    $res = $bdd->query($req);
    $Satisfaction = $res->fetchAll();
    return $Satisfaction;
}

function getStationsByLigne($bdd, $numLigne)
{
    $req = "SELECT s.nomStation
            FROM Station s
            JOIN Se_Situer se ON s.idStation = se.numStation
            WHERE se.numLigne = :numLigne";
    $res = $bdd->prepare($req);
    $res->bindParam(':numLigne', $numLigne, PDO::PARAM_INT);
    $res->execute();
    $stations = $res->fetchAll(PDO::FETCH_COLUMN);
    return $stations;
}

function GetSatisfactionParCritère($bdd, $critere)
{
    $condition = '';
    switch ($critere) {
        case 'option1':
            $condition = "WHERE c.libelle = 'Fréquence de bus'";
            break;
        case 'option2':
            $condition = "WHERE c.libelle = 'Itinéraire des lignes et stations desservies'";
            break;
        case 'option3':
            $condition = "WHERE c.libelle = 'Information sur le trafic'";
            break;
        case 'option4':
            $condition = "WHERE c.libelle = 'Point de vente de tickets et recharge des cartes d'";
            break;
        default:
            $condition = '';
            break;
    }

    $req = "SELECT s.degre AS satisfaction_degre, COUNT(cm.idCommentaire) AS nombre_commentaires
            FROM Commentaire cm
            JOIN Critere c ON cm.idCritere = c.idCritere
            JOIN Satisfaction s ON cm.idSatisfaction = s.idSatisfaction
            $condition
            GROUP BY s.degre";
    $res = $bdd->query($req);
    $Satisfaction = $res->fetchAll();
    return $Satisfaction;
}

function ajouterCommentaire($bdd, $numCritere, $numLigne, $numStation, $numSatisfaction, $commentaire)
{
    $req = "INSERT INTO Commentaire (idCritere, idLigne, idStation, idSatisfaction, commentaire) 
            VALUES (:numCritere, :numLigne, :numStation, :numSatisfaction, :commentaire)";

    $res = $bdd->prepare($req);
    return $res->execute([
        ':numCritere' => $numCritere,
        ':numLigne' => $numLigne,
        ':numStation' => $numStation,
        ':numSatisfaction' => $numSatisfaction,
        ':commentaire' => $commentaire
    ]);
}

