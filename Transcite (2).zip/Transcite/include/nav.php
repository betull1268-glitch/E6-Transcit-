<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <a class="navbar-brand" href="TranscitePage.php">Transcite</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="TranscitePage.php" style="display: inline-block;">Les lignes</a>
        <a class="nav-link" href="TranscitePageGuichets.php" style="display: inline-block;">Les lignes avec des stations sans guichet automatique</a>
        <a class="nav-link" href="TranscitePageSatisfaction.php" style="display: inline-block;">Statistiques sur la fréquence des bus</a>
        <a class="nav-link" href="TranscitePageCritère.php" style="display: inline-block;">Statistiques par critère</a>
        <a class="nav-link" href="TranscitePageCommentaire.php" style="display: inline-block;">Ajouter un commentaire</a>
      </li>
     
    </ul>
  </div>
</nav>