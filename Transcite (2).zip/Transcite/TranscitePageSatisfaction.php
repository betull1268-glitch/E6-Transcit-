<?php
  ini_set('display_errors', 'On');
  error_reporting(E_ALL);
?>
<!DOCTYPE html>
<html lang="fr">

<head>
  <?php
  include('include/head.php');
  ?>
</head>

<body>

  <?php
  include('include/header.php');
  include('include/nav.php');
  $Ligne = getLigne($bdd);
  $NbreStation = getGuichet($bdd);
  $Satisfaction = GetSatisfaction($bdd);
  $totalCommentaires = array_sum(array_column($Satisfaction, 'nombre_commentaires'));
  ?>

  <div class="jumbotron">
    <div class="container">
      <section>
        <h1>Statistiques sur la fréquence des bus </h1>
        <div class="row">
        <table class="table">
            <thead>
              <tr>
                <th scope="col">Degré de satisfaction</th>
                <th scope="col">Nombre de commentaires</th>
                <th scope="col">Pourcentage</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($Satisfaction)) { 
                foreach ($Satisfaction as $uneLigne) { 
                  $nombreCommentaire = $uneLigne['nombre_commentaires'];
                  $degre = $uneLigne['satisfaction_degre'];
                  $pourcentage = ($totalCommentaires > 0) ? ($nombreCommentaire / $totalCommentaires) * 100 : 0;
              ?>
                  <tr>
                    <td><?php echo htmlspecialchars($degre); ?></td>
                    <td><?php echo htmlspecialchars($nombreCommentaire); ?></td>
                    <td><?php echo number_format($pourcentage, 2); ?>%</td>
                  </tr>
              <?php } ?>
                  <tr style="font-weight: bold;">
                    <td>Total</td>
                    <td><?php echo htmlspecialchars($totalCommentaires); ?></td>
                    <td>100%</td>
                  </tr>
              <?php } else { ?>
                  <tr>
                    <td colspan="3">Aucune donnée disponible</td>
                  </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
      </section>
    </div>
  </div>

  <?php include('include/footer.php'); ?>

</body>

</html>