<?php
  ini_set('display_errors', 'On');
  error_reporting(E_ALL);
?>
<!DOCTYPE html>
<html lang="fr">

<head>
  <?php
  include('include/head.php');
  ?>
</head>

<body>

  <?php
  include('include/header.php');
  include('include/nav.php');
  $Ligne = getLigne($bdd);
  ?>

  <div class="jumbotron">
    <div class="container">
      <section>
        <h1>Liste des stations</h1>
        <div class="row">

          <?php
          foreach ($Ligne as $uneLigne) {
            $numLigne = $uneLigne['idLigne'];
            $stations = getStationsByLigne($bdd, $numLigne); 
          ?>
            <article class="col-md-4">
              <div class="card" style="width: 18rem;">
                <div class="card-body">
                  <h5 class="card-title"><?php echo "Ligne " . $numLigne ?></h5>
                  <p class="card-text"><strong>Stations de la ligne :</strong></p>
                  <ul>
                    <?php
                    if (!empty($stations)) {
                      foreach ($stations as $station) {
                        echo "<li>$station</li>";
                      }
                    } else {
                      echo "<li>Aucune station trouvée.</li>";
                    }
                    ?>
                  </ul>
                </div>
              </div>
              <br>
            </article>
          <?php } ?>
        </div>
      </section>
    </div>
  </div>

  <?php include('include/footer.php'); ?>

</body>

</html>