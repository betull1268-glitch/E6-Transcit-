<?php
  ini_set('display_errors', 'On');
  error_reporting(E_ALL);
?>
<!DOCTYPE html>
<html lang="fr">

<head>
  <?php
  include('include/head.php');
  ?>
</head>

<body>

  <?php
  include('include/header.php');
  include('include/nav.php');
  ?>

<div class="jumbotron">
    <div class="container">
        <section>
            <h1>Statistiques par critère </h1>
            <div class="row">
                <form action="" method="POST">
                    <label for="choix">Choisissez un critère :</label>
                    <select name="choix" id="choix">
                        <option value="option1" <?php if (isset($_POST['choix']) && $_POST['choix'] == 'option1') echo 'selected'; ?>>Fréquence de bus</option>
                        <option value="option2" <?php if (isset($_POST['choix']) && $_POST['choix'] == 'option2') echo 'selected'; ?>>Itinéraire des lignes et stations desservies</option>
                        <option value="option3" <?php if (isset($_POST['choix']) && $_POST['choix'] == 'option3') echo 'selected'; ?>>Information sur le trafic</option>
                        <option value="option4" <?php if (isset($_POST['choix']) && $_POST['choix'] == 'option4') echo 'selected'; ?>>Point de vente de tickets et recharge des cartes d’abonnement</option>
                    </select>
                    <br>
                    <button type="submit">Valider</button>
                </form>
            </div>
        </section>
    </div>
</div>


  <div class="jumbotron">
    <div class="container">
      <section>
        <div class="row">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">Degré de satisfaction</th>
                <th scope="col">Nombre de commentaires</th>
                <th scope="col">Pourcentage</th>
              </tr>
            </thead>
            <tbody>
              <?php
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                  $critere = $_POST['choix'];
                  $bdd = seConnecter();
                  $Satisfaction = GetSatisfactionParCritère($bdd, $critere);
                  if (!empty($Satisfaction)) {
                    $totalCommentaires = 0;
                    foreach ($Satisfaction as $uneLigne) {
                      $nombreCommentaire = $uneLigne['nombre_commentaires'];
                      $degre = $uneLigne['satisfaction_degre'];
                      $totalCommentaires += $nombreCommentaire;
                    }
                    foreach ($Satisfaction as $uneLigne) {
                      $nombreCommentaire = $uneLigne['nombre_commentaires'];
                      $degre = $uneLigne['satisfaction_degre'];
                      $pourcentage = ($totalCommentaires > 0) ? ($nombreCommentaire / $totalCommentaires) * 100 : 0;
              ?>
                  <tr>
                    <td><?php echo htmlspecialchars($degre); ?></td>
                    <td><?php echo htmlspecialchars($nombreCommentaire); ?></td>
                    <td><?php echo number_format($pourcentage, 2); ?>%</td>
                  </tr>
              <?php 
                    } 
              ?>
                  <tr style="font-weight: bold;">
                    <td>Total</td>
                    <td><?php echo htmlspecialchars($totalCommentaires); ?></td>
                    <td>100%</td>
                  </tr>
              <?php 
                  } else { 
              ?>
                  <tr>
                    <td colspan="3">Aucune donnée disponible pour ce critère.</td>
                  </tr>
              <?php 
                  }
                } 
              ?>
            </tbody>
          </table>
        </div>
      </section>
    </div>
  </div>

  <?php include('include/footer.php'); ?>

</body>

