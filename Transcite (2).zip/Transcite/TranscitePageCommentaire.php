<?php
  ini_set('display_errors', 'On');
  error_reporting(E_ALL);

  include('include/header.php');

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $critere = isset($_POST['critere']) ? (int) $_POST['critere'] : null;
    $ligne = isset($_POST['ligne']) ? (int) $_POST['ligne'] : null;
    $station = isset($_POST['station']) ? $_POST['station'] : null;
    $satisfaction = isset($_POST['satisfaction']) ? (int) $_POST['satisfaction'] : null;
    $commentaire = isset($_POST['commentaire']) ? trim($_POST['commentaire']) : null;


    if ($critere && $ligne && $station && $satisfaction && $commentaire) {
        $bdd = seConnecter();

        $resultat = ajouterCommentaire($bdd, $critere, $ligne, $station, $satisfaction, $commentaire);
        
        if ($resultat) {
            echo "Commentaire ajouté avec succès!";
        } else {
            echo "Erreur lors de l'ajout du commentaire.";
        }
    } else {
        echo "Veuillez remplir tous les champs.";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">

<head>
  <?php
  include('include/head.php');
  ?>
  <script>
    document.addEventListener("DOMContentLoaded", function () {
    const stationsParLigne = {
        "8": ["STA11", "STA13", "STA14", "STA15", "STA25"], 
        "10": ["STA12", "STA23", "STA24", "STA25", "STA26", "STA27"], 
        "26": ["STA22"]
    };

    const selectLigne = document.getElementById("ligne");
    const selectStation = document.getElementById("station");

    function updateStations(ligneChoisie) {
        selectStation.innerHTML = "";
        if (stationsParLigne[ligneChoisie]) {
            stationsParLigne[ligneChoisie].forEach(station => {
                const option = document.createElement("option");
                option.value = station;
                option.textContent = station;
                selectStation.appendChild(option);
            });
        }
    }

    updateStations("8");

    selectLigne.addEventListener("change", function () {
        updateStations(this.value);
    });

    const form = document.querySelector('form');
    form.addEventListener('submit', function(event) {
        const stationChoisie = selectStation.value;
        console.log("Station choisie: ", stationChoisie); 
    });
});
  </script>

</head>

<body>

  <?php
  include('include/nav.php');
  ?>

  <div class="jumbotron">
    <div class="container">
      <section>
        <h1>Ajouter un commentaire</h1>
        <div class="row">
          <form action="" method="POST">
            <label for="critere">Choisissez un critère :</label>
            <select name="critere" id="critere">
              <option value="1">Fréquence de bus</option>
              <option value="2">Itinéraire des lignes et stations desservies</option>
              <option value="3">Information sur le trafic</option>
              <option value="4">Point de vente de tickets et recharge des cartes d’abonnement</option>
            </select>
            <br>

            <label for="ligne">Choisissez une ligne :</label>
            <select name="ligne" id="ligne">
              <option value="8" selected>Ligne 8</option>
              <option value="10">Ligne 10</option>
              <option value="26">Ligne 26</option>
            </select>
            <br>

            <label for="station">Choisissez une station :</label>
            <select name="station" id="station">
            </select>
            <br>

            <label for="satisfaction">Choisissez un degré de satisfaction :</label>
            <select name="satisfaction" id="satisfaction">
              <option value="1">Très satisfait</option>
              <option value="2">Satisfait</option>
              <option value="3">Réservé</option>
              <option value="4">Insatisfait</option>
            </select>
            <br>

            <label for="commentaire">Votre commentaire :</label>
            <br>
            <textarea name="commentaire" id="commentaire" rows="4" cols="50" placeholder="Écrivez votre commentaire ici..."></textarea>
            <br>

            <button type="submit">Valider</button>
          </form>
        </div>
      </section>
    </div>
  </div>

  <?php include('include/footer.php'); ?>

</body>
</html>
