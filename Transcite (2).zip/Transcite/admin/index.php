<?php
echo ‘Vous êtes dans la partie administration de la base de données’ ;
?>