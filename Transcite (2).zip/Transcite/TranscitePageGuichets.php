<?php
  ini_set('display_errors', 'On');
  error_reporting(E_ALL);
?>
<!DOCTYPE html>
<html lang="fr">

<head>
  <?php
  include('include/head.php');
  ?>
</head>

<body>

  <?php
  include('include/header.php');
  include('include/nav.php');
  $Ligne = getLigne($bdd);
  $NbreStation = getGuichet($bdd);
  ?>

  <div class="jumbotron">
    <div class="container">
      <section>
        <h1>Liste des lignes avec des stations sans guichet automatique</h1>
        <div class="row">

          <?php
          foreach ($NbreStation as $uneLigne) {
            $numLigne = $uneLigne['ligne'];
            $nombre = $uneLigne['nombre_stations_sans_guichet'];
          ?>

            <article class="col-md-4">
              <div class="card" style="width: 18rem;">
                <div class="card-body">
                  <h5 class="card-title"><?php echo "Ligne" . " " . $numLigne ?></h5>
                  <p class="card-text"><?php echo "Nombres de station sans guichet automatique :" . "" .$nombre ?></p>
                </div>
              </div>

              <br>
            </article>
          <?php } ?>
        </div>
      </section>
    </div>
  </div>

  <?php include('include/footer.php'); ?>

</body>

</html>