<?php
  ini_set('display_errors', 'On');
  error_reporting(E_ALL);
?>
<!DOCTYPE html>
<html lang="fr">

<head>
  <?php
  include('include/head.php');
  ?>
</head>

<body>

  <?php
  include('include/header.php');
  include('include/nav.php');
  $Ligne = getLigne($bdd);
  ?>

  <div class="jumbotron">
    <div class="container">
      <section>
        <h1>Liste des lignes</h1>
        <div class="row">

          <?php
          foreach ($Ligne as $uneLigne) {
            $numLigne = $uneLigne['idLigne'];
            $communeDepart = $uneLigne['communeDepart'];
            $communeArrivee = $uneLigne['communeArrivee'];
          ?>

            <article class="col-md-4">
              <div class="card" style="width: 18rem;">
                <div class="card-body">
                  <h5 class="card-title"><?php echo "Ligne" . " " . $numLigne ?></h5>
                  <p class="card-text"><?php echo "Commune de Depart :" . " " . $communeDepart . "<br>" . "Commune d'Arrivée :" . " " . $communeArrivee ?></p>
                  <a href="TranscitePageStation.php" class="card-link">Voir les stations</a>
                </div>
              </div>

              <br>
            </article>
          <?php } ?>
        </div>
      </section>
    </div>
  </div>

  <?php include('include/footer.php'); ?>

</body>

</html>